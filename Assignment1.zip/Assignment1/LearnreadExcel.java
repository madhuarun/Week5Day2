package Week5day2;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class LearnreadExcel {

//	public static void ReadExcel(String fileName) throws IOException 
	public static void main(String args[]) throws IOException{
		// TODO Auto-generated method stub
		
		XSSFWorkbook excel = new XSSFWorkbook("./data/CreateLead.xlsx");
		
		XSSFSheet sheet = excel.getSheet("Sheet1");
		
		int rowcount = sheet.getLastRowNum();
		int colcount = sheet.getRow(0).getLastCellNum();
		
		System.out.println(rowcount);
		System.out.println(colcount);
		
		for(int i=1;i<=rowcount;i++) {
			
			for (int j = 0;j<colcount;j++) {
				String cellValue = sheet.getRow(i).getCell(j).getStringCellValue();
			
				System.out.println(cellValue);
				
			}
		}
		excel.close();

	}

}
