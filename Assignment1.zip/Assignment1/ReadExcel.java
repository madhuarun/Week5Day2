package Week5day2;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
	public static String[][] readData(String fileName) throws IOException {
		XSSFWorkbook excel = new XSSFWorkbook("./data/"+fileName+".xlsx");
		
		XSSFSheet sheet = excel.getSheet("Sheet1");
		
		//Get number of rows and columns in excel
		int rowcount = sheet.getLastRowNum();
		int colcount = sheet.getRow(0).getLastCellNum();
		
		//2d array that will contain excel data
		String[][] data = new String[rowcount][colcount];
		for(int i=1;i<=rowcount;i++) {
			
			for (int j = 0;j<colcount;j++) {
				String cellValue = sheet.getRow(i).getCell(j).getStringCellValue();
				data[i-1][j] = cellValue;
				System.out.println(cellValue);
				
			}
		}
		
		//Close the excel
		excel.close();
		//Return excel data to calling class
		return data;
		
		
	}

}
