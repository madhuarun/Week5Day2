package Week5day2;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;


public class CreateLead extends BaseClass{
	@BeforeTest
	public void setFileName() {
		excelFilename = "CreateLead";
	}
	@Test(dataProvider = "getData")
	public void createLead(String fName, String mName, String lName) throws InterruptedException {

			
	Thread.sleep(2000);
driver.findElement(By.linkText("Create Lead")).click();
driver.findElement(By.id("createLeadForm_companyName")).sendKeys(mName);
driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
driver.findElement(By.id("createLeadForm_departmentName")).sendKeys("sales");
driver.findElement(By.id("createLeadForm_description")).sendKeys("this is description");
driver.findElement(By.id("createLeadForm_primaryEmail")).sendKeys("testleaf@gmail.com");

WebElement eleDropdown=driver.findElement(By.id("createLeadForm_generalStateProvinceGeoId"));
Select dd=new Select(eleDropdown);
dd.selectByVisibleText("New York");

driver.findElement(By.name("submitButton")).click();

String title=driver.getTitle();
System.out.println(title);
	}




	

}
